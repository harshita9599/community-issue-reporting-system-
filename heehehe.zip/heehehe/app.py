from flask import Flask, request, jsonify, render_template, redirect, url_for, session, flash
from flask import render_template, request, redirect, url_for, flash
from flask_mail import Mail, Message
import random
import sqlite3
from werkzeug.security import generate_password_hash, check_password_hash
import os
from dotenv import load_dotenv
from werkzeug.utils import secure_filename

# Load environment variables
load_dotenv()

app = Flask(__name__)
app.secret_key = os.getenv("SECRET_KEY", "fallback_secret_key")

# Upload configuration
UPLOAD_FOLDER = 'static/uploads'
os.makedirs(UPLOAD_FOLDER, exist_ok=True)
app.config['UPLOAD_FOLDER'] = UPLOAD_FOLDER

# OTP storage (in-memory for simplicity)
otp_storage = {}

# Mail configuration
app.config.update(
    MAIL_SERVER='smtp.gmail.com',
    MAIL_PORT=587,
    MAIL_USE_TLS=True,
    MAIL_USERNAME=os.getenv('MAIL_USERNAME'),
    MAIL_PASSWORD=os.getenv('MAIL_PASSWORD')
)
mail = Mail(app)

# DB connection helper
def get_db_connection():
    conn = sqlite3.connect('users.db')
    conn.row_factory = sqlite3.Row
    return conn

@app.route('/')
def home():
    selected_state = request.args.get('state', '')
    selected_category = request.args.get('category', '')
    selected_status = request.args.get('status', '')

    query = "SELECT * FROM issues WHERE 1=1"
    params = []

    if selected_state:
     query += " AND LOWER(state) = ?"
     params.append(selected_state.lower())

    if selected_category:
     query += " AND LOWER(category) = ?"
     params.append(selected_category.lower())

    if selected_status:
     query += " AND LOWER(status) = ?"
     params.append(selected_status.lower())

    conn = get_db_connection()
    conn.row_factory = sqlite3.Row  # so you can access dict-like keys in template
    issues = conn.execute(query, params).fetchall()
    conn.close()

    issues_by_state = {}
    for issue in issues:
        state = issue['state']
        if state not in issues_by_state:
            issues_by_state[state] = []
        issues_by_state[state].append(issue)

    return render_template('dashboard.html',
                           issues_by_state=issues_by_state,
                           username=session.get('username'),
                           selected_state=selected_state,
                           selected_category=selected_category,
                           selected_status=selected_status)



@app.route('/login_page')
def login_landing():
    return render_template("login_landing.html")

@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        data = request.json
        email = data.get('email')
        password = data.get('password')

        if not all([email, password]):
            return jsonify(success=False, message="Email and password required"), 400

        conn = get_db_connection()
        user = conn.execute("SELECT * FROM users WHERE email = ?", (email,)).fetchone()
        conn.close()

        if user and check_password_hash(user['password'], password):
            session['username'] = user['username']
            return jsonify(success=True, username=user['username'])
        else:
            return jsonify(success=False, message="Invalid credentials")

    return render_template("user_login.html")

@app.route('/register', methods=['GET', 'POST'])
def register_page():
    if request.method == 'POST':
        data = request.json
        email = data.get('email')
        otp = data.get('otp')
        username = data.get('username')
        password = data.get('password')

        if not all([email, otp, username, password]):
            return jsonify(success=False, message="All fields are required"), 400

        if otp_storage.get(email) != otp:
            return jsonify(success=False, message="OTP mismatch")

        hashed_pw = generate_password_hash(password)

        try:
            conn = get_db_connection()
            conn.execute(
                "INSERT INTO users (username, email, password) VALUES (?, ?, ?)",
                (username, email, hashed_pw)
            )
            conn.commit()
            conn.close()
            otp_storage.pop(email, None)
            return jsonify(success=True, message="User registered successfully")
        except sqlite3.IntegrityError:
            return jsonify(success=False, message="Username or Email already exists")

    return render_template("register.html")

@app.route('/send_otp', methods=['POST'])
def send_otp():
    email = request.json.get('email')
    if not email:
        return jsonify(success=False, message="Email is required"), 400

    otp = str(random.randint(100000, 999999))
    otp_storage[email] = otp

    msg = Message('Your OTP Code', sender=app.config['MAIL_USERNAME'], recipients=[email])
    msg.body = f'Your OTP is: {otp}'

    try:
        mail.send(msg)
        return jsonify(success=True, message="OTP sent")
    except Exception as e:
        print(f"Mail send failed: {e}")
        return jsonify(success=False, message="Failed to send OTP")

@app.route('/logout')
def logout():
    session.clear()
    return redirect(url_for('home'))

@app.route('/report')
def report():
    if 'username' not in session:
        return redirect(url_for('login'))
    return render_template('report.html', username=session['username'])

@app.route('/submit_issue', methods=['POST'])
def submit_issue():
    if 'username' not in session:
        return redirect(url_for('login'))

    title = request.form['title']
    category = request.form['category']
    description = request.form['description']
    state = request.form['state']
    location = request.form['location']
    username = session['username']

    image = request.files.get('image')
    image_filename = None

    if image and image.filename != '':
        image_filename = secure_filename(image.filename)
        image.save(os.path.join(app.config['UPLOAD_FOLDER'], image_filename))

    conn = get_db_connection()
    conn.execute('''
        INSERT INTO issues (title, category, description, state, location, image, username)
        VALUES (?, ?, ?, ?, ?, ?, ?)
    ''', (title, category, description, state, location, image_filename, username))
    conn.commit()
    conn.close()

    return redirect(url_for('home'))

@app.route('/dashboard')
def dashboard():
    if 'username' not in session:
        return redirect(url_for('login'))

    username = session['username']
    conn = get_db_connection()
    issues = conn.execute(
        'SELECT * FROM issues WHERE username = ? ORDER BY timestamp DESC', (username,)
    ).fetchall()
    conn.close()

    # Group issues by state for template compatibility
    issues_by_state = {}
    for issue in issues:
        issue_dict = dict(issue)
        # fix: add date here
        issue_dict['date'] = issue_dict.get('timestamp', '')  # use timestamp column as date
        issue_dict['status'] = issue_dict['status'].replace(" ", "-")
        state = issue_dict['state']
        if state not in issues_by_state:
            issues_by_state[state] = []
        issues_by_state[state].append(issue_dict)

    return render_template('dashboard.html', username=username, issues_by_state=issues_by_state)


@app.route('/my_issues')
def my_issues():
    if 'username' not in session:
        return redirect(url_for('login'))

    username = session['username']

    conn = sqlite3.connect('users.db')
    c = conn.cursor()
    c.execute('''
        SELECT id, title, category, description, state, location,
            image, status, timestamp, user_feedback, comment, user_confirmed
        FROM issues
        WHERE username = ?
    ''', (username,))

    rows = c.fetchall()
    conn.close()

    issues = []
    for row in rows:
        issues.append({
            'id': row[0],
            'title': row[1],
            'category': row[2],
            'description': row[3],
            'state': row[4],
            'location': row[5],
            'image': row[6],
            'status': row[7],
            'date': row[8],
            'user_feedback': row[9],
            'comment': row[10],
            'user_confirmed': row[11] if len(row) > 11 else 'No'
        })

    return render_template('my_issues.html', username=username, issues=issues)

@app.route('/submit_feedback', methods=['POST'])
def submit_feedback():
    issue_id = request.form['issue_id']
    feedback = request.form['feedback']

    conn = sqlite3.connect('users.db')
    c = conn.cursor()
    c.execute("UPDATE issues SET user_feedback = ? WHERE id = ?", (feedback, issue_id))
    conn.commit()
    conn.close()

    return redirect(url_for('my_issues'))

@app.route('/confirm_resolved', methods=['POST'])
def confirm_resolved():
    if 'username' not in session:
        return redirect(url_for('login'))

    issue_id = request.form['issue_id']
    response = request.form['response']

    conn = get_db_connection()
    conn.execute("UPDATE issues SET user_confirmed = ? WHERE id = ?", (response, issue_id))
    conn.commit()
    conn.close()

    return redirect(url_for('my_issues'))

@app.route('/authority_login', methods=['GET', 'POST'])
def authority_login():
    if request.method == 'POST':
        authority_id = request.form['authority_id']
        password = request.form['password']

        conn = sqlite3.connect('users.db')
        c = conn.cursor()
        c.execute("SELECT * FROM authorities WHERE authority_id=? AND password=?", (authority_id, password))
        result = c.fetchone()
        conn.close()

        if result:
            session['authority_id'] = result[1]
            session['authority_state'] = result[4]  # result[4] = state
            return redirect(url_for('authority_dashboard'))
        else:
            return "Invalid credentials"
    return render_template('authority_login.html')
@app.route('/authority_dashboard')
def authority_dashboard():
    if 'authority_id' not in session:
        return redirect(url_for('authority_login'))

    authority_id = session['authority_id']
    authority_state = session['authority_state'].lower()
    current_state = (request.args.get('state') or authority_state).lower()

    conn = get_db_connection()
    all_issues = conn.execute("SELECT * FROM issues").fetchall()
    conn.close()

    # Group issues by state
    state_issues = {}
    for issue in all_issues:
        state = issue['state'].lower()
        if state not in state_issues:
            state_issues[state] = []
        state_issues[state].append(dict(issue))

    # Separately track confirmed resolved issues
    confirmed_resolved_issues = {}
    for issue in all_issues:
        if issue['status'] == 'Resolved' and issue['user_confirmed'] == 'Yes':
            state = issue['state'].lower()
            if state not in confirmed_resolved_issues:
                confirmed_resolved_issues[state] = []
            confirmed_resolved_issues[state].append(dict(issue))

    return render_template("authority_dashboard.html",
                           authority_id=authority_id,
                           authority_state=authority_state,
                           current_state=current_state,
                           state_issues=state_issues,
                           confirmed_resolved_issues=confirmed_resolved_issues)


@app.route('/authority/resolved')
def authority_resolved_issues():
    if 'authority_id' not in session:
        return redirect(url_for('authority_login'))

    authority_id = session['authority_id']

    conn = sqlite3.connect('users.db')
    conn.row_factory = sqlite3.Row
    c = conn.cursor()

    # ✅ Fetch the authority's state
    c.execute("SELECT state FROM authorities WHERE authority_id = ?", (authority_id,))
    result = c.fetchone()
    if not result:
        return "Authority not found", 404
    authority_state = result['state']

    # ✅ Fetch resolved issues confirmed by user only in that state
    c.execute("""
        SELECT * FROM issues 
        WHERE LOWER(state) = ? AND status = 'Resolved' AND user_confirmed = 'Yes'
        ORDER BY timestamp DESC
    """, (authority_state.lower(),))

    issues = c.fetchall()
    conn.close()

    return render_template(
    'resolved_issues.html',
    issues=issues,
    authority_id=authority_id,
    authority_state=authority_state,          # ← keep
    current_state=authority_state             # ← add
)



...
# Insert this new route into your app.py
@app.route('/confirm_resolution', methods=['POST'])
def confirm_resolution():
    if 'username' not in session:
        return redirect(url_for('login'))

    issue_id = request.form.get('issue_id')
    feedback = request.form.get('feedback')  # Either 'Yes' or 'No'

    conn = get_db_connection()
    c = conn.cursor()

    if feedback == 'Yes':
        c.execute("""
            UPDATE issues
            SET user_confirmed = 'Yes'
            WHERE id = ?
        """, (issue_id,))
        flash("Thanks for confirming that the issue has been resolved ✅")

    elif feedback == 'No':
        c.execute("""
            UPDATE issues
            SET status = 'Pending', user_confirmed = 'No'
            WHERE id = ?
        """, (issue_id,))
        flash("Your issue has been sent back to the authority 🚧")

    conn.commit()
    conn.close()

    return redirect(url_for('my_issues'))

# ----------  view issues by status  ----------
@app.route('/authority/issues/<status>')
def view_issues_by_status(status):
    """
    Shows all issues (in the authority’s state) that match the given status.
    status will be 'Pending', 'In Progress', or 'Resolved'.
    """
    if 'authority_id' not in session:
        return redirect(url_for('authority_login'))

    authority_state = session['authority_state'].lower()

    conn = get_db_connection()
    issues = conn.execute(
        """
        SELECT * FROM issues
        WHERE LOWER(state) = ? AND LOWER(status) = ?
        ORDER BY timestamp DESC
        """,
        (authority_state, status.lower())
    ).fetchall()
    conn.close()
    
    return render_template(
    'authority_issues_list.html',
    status=status,
    issues=issues,
    authority_id=session['authority_id'],
    authority_state=authority_state,          # ← add
    current_state=authority_state             # ← add
)


# ------------------ UPDATE STATUS & COMMENT ------------------
@app.route('/update_status', methods=['POST'])
def update_status():
    if 'authority_id' not in session:
        return redirect(url_for('authority_login'))

    authority_state = session['authority_state'].lower()
    issue_id = request.form['issue_id']
    new_status = request.form['status']
    comment = request.form['comment']

    conn = get_db_connection()
    c = conn.cursor()

    c.execute("SELECT state FROM issues WHERE id = ?", (issue_id,))
    result = c.fetchone()

    if result and result['state'].lower() == authority_state:
        c.execute("UPDATE issues SET status = ?, comment = ? WHERE id = ?", (new_status, comment, issue_id))
        conn.commit()

    conn.close()
    return redirect(url_for('authority_dashboard'))


# ------------------ ADD COMMENT (optional, legacy) ------------------

@app.route('/add_comment', methods=['POST'])
def add_comment():
    issue_id = request.form['issue_id']
    comment = request.form['comment']

    conn = get_db_connection()
    c = conn.cursor()
    c.execute("UPDATE issues SET comment = ? WHERE id = ?", (comment, issue_id))
    conn.commit()
    conn.close()

    return redirect(url_for('authority_dashboard'))


# ------------------ EDIT ISSUE ------------------

@app.route('/edit_issue/<int:issue_id>', methods=['GET', 'POST'])
def edit_issue(issue_id):
    if 'authority_id' not in session:
        return redirect(url_for('authority_login'))

    conn = get_db_connection()
    c = conn.cursor()

    if request.method == 'POST':
        title = request.form['title']
        description = request.form['description']
        location = request.form['location']
        status = request.form['status']

        c.execute("""
            UPDATE issues
            SET title = ?, description = ?, location = ?, status = ?
            WHERE id = ?
        """, (title, description, location, status, issue_id))

        conn.commit()
        conn.close()
        return redirect(url_for('authority_dashboard'))

    # GET request — show issue data
    c.execute("SELECT * FROM issues WHERE id = ?", (issue_id,))
    issue = c.fetchone()
    conn.close()

    if not issue:
        return "Issue not found"

    return render_template('edit_issue.html', issue=issue)
@app.route('/authority_logout')
def authority_logout():
    session.pop('authority_id', None)
    session.pop('authority_state', None)
    return redirect(url_for('home'))


if __name__ == '__main__':
    app.run(debug=True)

