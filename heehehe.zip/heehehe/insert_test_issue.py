import sqlite3

conn = sqlite3.connect('users.db')
c = conn.cursor()

# Create users table
c.execute('''
CREATE TABLE IF NOT EXISTS users (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    username TEXT UNIQUE NOT NULL,
    email TEXT UNIQUE NOT NULL,
    password TEXT NOT NULL
)
''')

# Create issues table
c.execute('''
CREATE TABLE IF NOT EXISTS issues (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    title TEXT NOT NULL,
    category TEXT NOT NULL,
    description TEXT NOT NULL,
    state TEXT NOT NULL,
    location TEXT NOT NULL,
    image TEXT,
    status TEXT DEFAULT 'Pending',
    timestamp DATETIME DEFAULT CURRENT_TIMESTAMP,
    username TEXT NOT NULL,
    comment TEXT,
    user_feedback TEXT,
    user_confirmed TEXT DEFAULT 'No'
)
''')

# Create authorities table
c.execute('''
CREATE TABLE IF NOT EXISTS authorities (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    authority_id TEXT UNIQUE NOT NULL,
    password TEXT NOT NULL,
    secret_code TEXT NOT NULL,
    state TEXT NOT NULL
)
''')

conn.commit()
conn.close()

print("✅ Database setup complete.")
