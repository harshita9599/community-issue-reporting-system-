import sqlite3

def column_exists(cursor, table, column):
    cursor.execute(f"PRAGMA table_info({table})")
    columns = [info[1] for info in cursor.fetchall()]
    return column in columns

# Connect to the database file
conn = sqlite3.connect('users.db')
c = conn.cursor()

# Create users table
c.execute('''
CREATE TABLE IF NOT EXISTS users (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    username TEXT UNIQUE NOT NULL,
    email TEXT UNIQUE NOT NULL,
    password TEXT NOT NULL
)
''')

# Create issues table
c.execute('''
CREATE TABLE IF NOT EXISTS issues (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    title TEXT NOT NULL,
    category TEXT NOT NULL,
    description TEXT NOT NULL,
    state TEXT NOT NULL,
    location TEXT NOT NULL,
    image TEXT,
    status TEXT DEFAULT 'Pending',
    timestamp DATETIME DEFAULT CURRENT_TIMESTAMP,
    username TEXT NOT NULL
)
''')

# Add missing columns: comment and user_feedback
# Add missing columns: comment, user_feedback, and user_confirmed
if not column_exists(c, 'issues', 'comment'):
    c.execute("ALTER TABLE issues ADD COLUMN comment TEXT")
    print("✅ Added 'comment' column to issues table")

if not column_exists(c, 'issues', 'user_feedback'):
    c.execute("ALTER TABLE issues ADD COLUMN user_feedback TEXT")
    print("✅ Added 'user_feedback' column to issues table")

# Add user_confirmed column to track if user confirmed the resolution
if not column_exists(c, 'issues', 'user_confirmed'):
    c.execute("ALTER TABLE issues ADD COLUMN user_confirmed TEXT DEFAULT 'No'")
    print("✅ Added 'user_confirmed' column to issues table")



# Create authorities table
c.execute('''
CREATE TABLE IF NOT EXISTS authorities (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    authority_id TEXT UNIQUE NOT NULL,
    password TEXT NOT NULL,
    secret_code TEXT NOT NULL,
    state TEXT NOT NULL
)
''')

# Insert default authorities
c.executemany('''
INSERT OR IGNORE INTO authorities (authority_id, password, secret_code, state)
VALUES (?, ?, ?, ?)
''', [
    ('auth_punjab', 'pass123', 'codePB', 'Punjab'),
    ('auth_delhi', 'pass234', 'codeDL', 'Delhi'),
    ('auth_rajasthan', 'pass345', 'codeRJ', 'Rajasthan'),
    ('auth_maha', 'pass456', 'codeMH', 'Maharashtra'),
    ('auth_hp', 'pass567', 'codeHP', 'Himachal Pradesh')
])

# Print table structures for verification
print("\n[users table columns]")
c.execute("PRAGMA table_info(users)")
for row in c.fetchall():
    print(row)

print("\n[issues table columns]")
c.execute("PRAGMA table_info(issues)")
for row in c.fetchall():
    print(row)

c.execute("PRAGMA table_info(issues)")
for col in c.fetchall():
    print(col)

c.execute("""
SELECT id, title, status, user_confirmed, state
FROM issues
WHERE status = 'Resolved' AND user_confirmed = 'Yes';
""")

conn.commit()
conn.close()
print("\n✅ Database initialized.")
