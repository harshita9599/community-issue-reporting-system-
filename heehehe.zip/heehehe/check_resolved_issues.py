import sqlite3

conn = sqlite3.connect("users.db")
c = conn.cursor()

c.execute("""
SELECT id, title, state, status, user_confirmed
FROM issues
WHERE status='Resolved' AND user_confirmed='Yes'
""")

rows = c.fetchall()

if not rows:
    print("❌ No issues found with status='Resolved' and user_confirmed='Yes'")
else:
    for row in rows:
        print(f"✅ ID: {row[0]} | Title: {row[1]} | State: {row[2]} | Status: {row[3]} | Confirmed: {row[4]}")

conn.close()
